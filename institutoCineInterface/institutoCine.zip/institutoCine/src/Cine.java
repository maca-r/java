public class Cine {
    private String nombre;
    private String direccion;
    private Integer cantidadEspectadores;

    public Cine(String nombre, String direccion, Integer cantidadEspectadores) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.cantidadEspectadores = cantidadEspectadores;
    }
}
